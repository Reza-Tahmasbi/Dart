import 'dart:ui';

class LightThemeColors{
  static const primaryColor = Color(0xff217CF3);
  static const secondaryColor = Color(0xff262A35);
  static const primaryTextColor = Color(0xff262A35);
  static const secondaryTextColor = Color(0xff83B6BE);
}