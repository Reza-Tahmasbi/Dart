class AppExecption{
  final String message;
  AppExecption({this.message = "خطای نامشخص"});
}